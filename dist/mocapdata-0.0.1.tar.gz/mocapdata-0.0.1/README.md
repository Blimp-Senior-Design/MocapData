# MoCap Data collection

This repository contains code that allows us to 
collect data from OpTitrack Motion Capture system 
and Vizualize it.

To run use the following command 

```bash
python capture/collect.py
```
